PNGOUT by Ken Silverman (http://advsys.net/ken)
Linux and BSD ports by Jonathon Fowler (http://www.jonof.id.au/pngout)
Mac OS X port by Ken Silverman, with assistance by Jonathon Fowler

08 November 2009 Release
